<div class="supafaya-logout-container" style="display: none;">
    <div class="supafaya-firebase-user-info"></div>
    <button class="firebase-logout-button">Log Out</button>
</div> 